 
 
 
 const getSendMailIdText = ()=>{
 }{ approval === 'Yes' && selectedTL && con  ? selectedTL: }
 (providedToList ?? toList)
                      ?.map((r) => r?.value || r?.text)
                      .filter(Boolean)
                      .join(', ') || 'recipient'