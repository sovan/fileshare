import express from "express";
import cors from "cors";
import axios from "axios";
import dotenv from "dotenv";
import multer from "multer";
import FormData from "form-data";

dotenv.config();

const app = express();
const PORT = 3001;

app.use(
  cors({
    origin: "http://localhost:5173",
    credentials: true,
  })
);

// Parse JSON and URL-encoded for non-multipart requests
app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));

// Multer for multipart (in-memory). For very large files, consider disk or streaming.
const upload = multer({ storage: multer.memoryStorage() });

// Main proxy handler
app.use("/api", (req, res, next) => {
  // If it's multipart/form-data, let multer parse it; otherwise continue normally
  if (req.is("multipart/form-data")) {
    upload.any()(req, res, (err) => {
      if (err)
        return res
          .status(400)
          .json({ error: "Invalid multipart data", details: err.message });
      handleProxy(req, res, { isMultipart: true }).catch(next);
    });
  } else {
    handleProxy(req, res, { isMultipart: false }).catch(next);
  }
});

async function handleProxy(req, res, { isMultipart }) {
  const method = req.method;
  // Keep the original path and query string after /api/
  const endpoint = req.originalUrl.replace(/^\/api\//, "");
 // const url = `https://dev.taazure.non-prod.uk-digital.engineering.vodafone.com/${endpoint}`;
  // const url = `https://sit-apex.taazure.non-prod.uk-digital.engineering.vodafone.com/${endpoint}`;
  const url = `https://orca-dev1-api.taazure.non-prod.uk-digital.engineering.vodafone.com/${endpoint}`;
  let data;
  let headers = {
    Authorization: req.headers.authorization || "",

    cookie: req.headers.authorization || "",
    accept: req.headers.accept || "*/*",
    "user-agent": req.headers["user-agent"] || "Mozilla/5.0",
    // You can propagate Authorization or other headers if needed:
    // authorization: req.headers.authorization,
   // cookie: `CF_AppSession=${process.env.CF_APPSESSION}; CF_Authorization=${process.env.CF_AUTHORIZATION}`,
  };

  if (isMultipart) {
    // Build a FormData body containing fields and files parsed by multer
    const form = new FormData();

    // Text fields (multer puts text fields in req.body)
    if (req.body) {
      Object.entries(req.body).forEach(([key, value]) => {
        // handle arrays (multer may flatten multi-value fields differently)
        if (Array.isArray(value)) {
          value.forEach((v) => form.append(key, v));
        } else {
          form.append(key, value);
        }
      });
    }

    // Files (multer puts them in req.files as buffers)
    if (Array.isArray(req.files)) {
      for (const file of req.files) {
        form.append(file.fieldname, file.buffer, {
          filename: file.originalname,
          contentType: file.mimetype,
          knownLength: file.size,
        });
      }
    }

    data = form;
    // Merge form headers to set the correct multipart boundary
    headers = { ...headers, ...form.getHeaders() };
  } else {
    // Non-multipart: forward JSON or URL-encoded body as-is
    // For GET/HEAD there is no body
    const hasBody = !["GET", "HEAD"].includes(method.toUpperCase());
    data = hasBody ? req.body : undefined;

    // Preserve incoming content-type if present; default to JSON when sending a body
    const incomingType = req.headers["content-type"];
    if (hasBody) {
      headers["content-type"] =
        incomingType && typeof incomingType === "string"
          ? incomingType
          : "application/json";
    }
  }

  try {
    const response = await axios({
      method,
      url,
      data,
      // If you prefer, you can also pass `params: req.query` but url already includes the query
      headers,
      // Big uploads:
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
      // Optional: keep non-2xx responses from throwing; we already handle errors below, so not necessary
      // validateStatus: () => true,
    });

    // Pass through upstream status + data
    res.status(response.status);
    // If upstream returns non-JSON, forward as-is
    const contentType = response.headers["content-type"] || "";
    if (contentType.includes("application/json")) {
      res.json(response.data);
    } else {
      // For other content types, set the header and send raw data
      res.set("content-type", contentType);
      res.send(response.data);
    }
  } catch (error) {
    if (error.response) {
      // Forward upstream error response
      res
        .status(error.response.status)
        .set(
          "content-type",
          error.response.headers?.["content-type"] || "application/json"
        )
        .send(error.response.data);
    } else {
      res
        .status(500)
        .json({ error: "API call failed", details: error.message });
    }
  }
}

// Basic error handler (last)
app.use((err, req, res, next) => {
  console.error("Proxy error:", err);
  res
    .status(500)
    .json({ error: "Internal server error", details: err.message });
});

app.listen(PORT, () => {
  console.log(`🚀 Dynamic API server running at http://localhost:${PORT}`);
});
 